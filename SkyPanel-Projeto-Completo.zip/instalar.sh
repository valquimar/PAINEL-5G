#!/bin/bash
echo 'Instalador SkyPanel'